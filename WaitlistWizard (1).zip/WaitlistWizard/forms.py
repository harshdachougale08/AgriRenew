from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, TextAreaField, SelectField, FloatField, DateField, SubmitField
from wtforms.validators import DataRequired, Email, EqualTo, Length, Optional

class FarmerRegistrationForm(FlaskForm):
    name = StringField('Full Name', validators=[DataRequired(), Length(min=2, max=100)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    phone = StringField('Phone Number', validators=[DataRequired()])
    farm_location = StringField('Farm Location', validators=[DataRequired()])
    farm_size = StringField('Farm Size (acres)', validators=[DataRequired()])
    password = PasswordField('Password', validators=[
        DataRequired(),
        Length(min=8, message='Password must be at least 8 characters')
    ])
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(),
        EqualTo('password', message='Passwords must match')
    ])
    submit = SubmitField('Register as Farmer')

class IndustrialistRegistrationForm(FlaskForm):
    name = StringField('Full Name', validators=[DataRequired(), Length(min=2, max=100)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    phone = StringField('Phone Number', validators=[DataRequired()])
    company_name = StringField('Company Name', validators=[DataRequired()])
    company_location = StringField('Company Location', validators=[DataRequired()])
    password = PasswordField('Password', validators=[
        DataRequired(),
        Length(min=8, message='Password must be at least 8 characters')
    ])
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(),
        EqualTo('password', message='Passwords must match')
    ])
    submit = SubmitField('Register as Industrialist')

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class ContactForm(FlaskForm):
    name = StringField('Your Name', validators=[DataRequired(), Length(min=2, max=100)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    subject = StringField('Subject', validators=[DataRequired(), Length(min=5, max=200)])
    message = TextAreaField('Message', validators=[DataRequired(), Length(min=10)])
    submit = SubmitField('Send Message')

class WasteListingForm(FlaskForm):
    waste_type = SelectField('Waste Type', choices=[
        ('crop_residue', 'Crop Residue'),
        ('animal_waste', 'Animal Waste'),
        ('green_waste', 'Green Waste'),
        ('food_waste', 'Food Processing Waste'),
        ('other', 'Other')
    ], validators=[DataRequired()])
    quantity = FloatField('Quantity (in tons)', validators=[DataRequired()])
    description = TextAreaField('Description', validators=[DataRequired(), Length(min=10)])
    location = StringField('Location', validators=[DataRequired()])
    available_from = DateField('Available From', validators=[DataRequired()])
    available_until = DateField('Available Until', validators=[DataRequired()])
    submit = SubmitField('Create Listing')
