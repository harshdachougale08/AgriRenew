document.addEventListener('DOMContentLoaded', function() {
    // Toggle between farmer and industrialist registration forms
    const userTypeTabs = document.querySelectorAll('.user-type-tab');
    const farmerForm = document.getElementById('farmer-form');
    const industrialistForm = document.getElementById('industrialist-form');

    if (userTypeTabs.length && farmerForm && industrialistForm) {
        userTypeTabs.forEach(tab => {
            tab.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Remove active class from all tabs
                userTypeTabs.forEach(t => t.classList.remove('active'));
                
                // Add active class to clicked tab
                this.classList.add('active');
                
                // Show the relevant form
                if (this.getAttribute('data-user-type') === 'farmer') {
                    farmerForm.style.display = 'block';
                    industrialistForm.style.display = 'none';
                } else {
                    farmerForm.style.display = 'none';
                    industrialistForm.style.display = 'block';
                }
            });
        });
    }

    // Form validation
    const validateForm = (form) => {
        let isValid = true;
        
        // Check required fields
        form.querySelectorAll('[required]').forEach(field => {
            if (!field.value.trim()) {
                isValid = false;
                
                // Add error class if not already present
                if (!field.classList.contains('is-invalid')) {
                    field.classList.add('is-invalid');
                    
                    // Create error message
                    const errorMsg = document.createElement('div');
                    errorMsg.className = 'invalid-feedback';
                    errorMsg.textContent = 'This field is required';
                    
                    // Add error message after the field
                    field.parentNode.appendChild(errorMsg);
                }
            } else {
                // Remove error class and message if field is valid
                field.classList.remove('is-invalid');
                const errorMsg = field.parentNode.querySelector('.invalid-feedback');
                if (errorMsg) {
                    errorMsg.remove();
                }
            }
        });
        
        // Email validation
        const emailField = form.querySelector('input[type="email"]');
        if (emailField && emailField.value.trim()) {
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(emailField.value)) {
                isValid = false;
                emailField.classList.add('is-invalid');
                
                // Create error message if not exists
                if (!emailField.parentNode.querySelector('.invalid-feedback')) {
                    const errorMsg = document.createElement('div');
                    errorMsg.className = 'invalid-feedback';
                    errorMsg.textContent = 'Please enter a valid email address';
                    emailField.parentNode.appendChild(errorMsg);
                }
            }
        }
        
        // Password validation (if password field exists)
        const passwordField = form.querySelector('input[type="password"]');
        const confirmPasswordField = form.querySelector('input[name="confirm_password"]');
        
        if (passwordField && passwordField.value.trim()) {
            if (passwordField.value.length < 8) {
                isValid = false;
                passwordField.classList.add('is-invalid');
                
                // Create error message if not exists
                if (!passwordField.parentNode.querySelector('.invalid-feedback')) {
                    const errorMsg = document.createElement('div');
                    errorMsg.className = 'invalid-feedback';
                    errorMsg.textContent = 'Password must be at least 8 characters';
                    passwordField.parentNode.appendChild(errorMsg);
                }
            }
            
            // Check if passwords match (if confirm password field exists)
            if (confirmPasswordField && confirmPasswordField.value.trim()) {
                if (passwordField.value !== confirmPasswordField.value) {
                    isValid = false;
                    confirmPasswordField.classList.add('is-invalid');
                    
                    // Create error message if not exists
                    if (!confirmPasswordField.parentNode.querySelector('.invalid-feedback')) {
                        const errorMsg = document.createElement('div');
                        errorMsg.className = 'invalid-feedback';
                        errorMsg.textContent = 'Passwords must match';
                        confirmPasswordField.parentNode.appendChild(errorMsg);
                    }
                }
            }
        }
        
        return isValid;
    };

    // Apply validation to all forms
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!validateForm(this)) {
                e.preventDefault();
            }
        });
        
        // Clear validation errors when typing
        form.querySelectorAll('input, textarea, select').forEach(field => {
            field.addEventListener('input', function() {
                this.classList.remove('is-invalid');
                const errorMsg = this.parentNode.querySelector('.invalid-feedback');
                if (errorMsg) {
                    errorMsg.remove();
                }
            });
        });
    });

    // Image carousel initialization (if exists)
    const carousel = document.querySelector('.carousel');
    if (carousel && typeof bootstrap !== 'undefined') {
        new bootstrap.Carousel(carousel, {
            interval: 5000,
            wrap: true
        });
    }

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            
            if (targetId !== '#' && document.querySelector(targetId)) {
                e.preventDefault();
                
                document.querySelector(targetId).scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // Initialize tooltips (if exists)
    if (typeof bootstrap !== 'undefined') {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
});
