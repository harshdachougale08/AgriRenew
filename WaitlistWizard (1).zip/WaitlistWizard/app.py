import os
import logging
from datetime import datetime
from flask import Flask, render_template, redirect, url_for, flash, request, session
from flask_wtf.csrf import CSRFProtect
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user, logout_user, login_required, current_user

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")
csrf = CSRFProtect(app)

# Initialize extensions
from database import login_manager
login_manager.init_app(app)
login_manager.login_view = 'login'

# Import models
from models import User, WasteListing, ContactMessage

@login_manager.user_loader
def load_user(user_id):
    return User.get_by_id(user_id)

from forms import (
    FarmerRegistrationForm, 
    IndustrialistRegistrationForm, 
    LoginForm, 
    ContactForm, 
    WasteListingForm
)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/process')
def process():
    return render_template('process.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    farmer_form = FarmerRegistrationForm()
    industrialist_form = IndustrialistRegistrationForm()
    
    if request.method == 'POST':
        if 'farmer_submit' in request.form and farmer_form.validate_on_submit():
            email = farmer_form.email.data
            
            # Check if email already exists
            existing_user = User.get_by_email(email)
            if existing_user:
                flash('Email already registered. Please login instead.', 'warning')
                return redirect(url_for('login'))
            
            # Create farmer user
            user = User(
                name=farmer_form.name.data,
                email=email,
                phone=farmer_form.phone.data,
                password=generate_password_hash(farmer_form.password.data),
                user_type='farmer',
                farm_location=farmer_form.farm_location.data,
                farm_size=farmer_form.farm_size.data
            )
            
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
            
        elif 'industrialist_submit' in request.form and industrialist_form.validate_on_submit():
            email = industrialist_form.email.data
            
            # Check if email already exists
            existing_user = User.get_by_email(email)
            if existing_user:
                flash('Email already registered. Please login instead.', 'warning')
                return redirect(url_for('login'))
            
            # Create industrialist user
            user = User(
                name=industrialist_form.name.data,
                email=email,
                phone=industrialist_form.phone.data,
                password=generate_password_hash(industrialist_form.password.data),
                user_type='industrialist',
                company_name=industrialist_form.company_name.data,
                company_location=industrialist_form.company_location.data
            )
            
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
    
    return render_template('register.html', farmer_form=farmer_form, industrialist_form=industrialist_form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    
    if form.validate_on_submit():
        email = form.email.data
        password = form.password.data
        
        user = User.get_by_email(email)
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            flash('Login successful!', 'success')
            return redirect(url_for('profile'))
        else:
            flash('Invalid email or password. Please try again.', 'danger')
    
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

@app.route('/profile')
@login_required
def profile():
    # Get current user's waste listings
    user_listings = WasteListing.get_by_user_id(current_user.id)
    
    return render_template('profile.html', user=current_user, listings=user_listings)

@app.route('/waste-listing', methods=['GET', 'POST'])
@login_required
def waste_listing():
    form = WasteListingForm()
    
    if form.validate_on_submit():
        # Create new waste listing
        new_listing = WasteListing(
            user_id=current_user.id,
            waste_type=form.waste_type.data,
            quantity=form.quantity.data,
            description=form.description.data,
            location=form.location.data,
            available_from=form.available_from.data,
            available_until=form.available_until.data
        )
        
        flash('Waste listing created successfully!', 'success')
        return redirect(url_for('profile'))
    
    # Get listings based on user type
    if current_user.user_type == 'industrialist':
        # For industrialists, show all listings
        all_listings = WasteListing.get_all()
        
        # Get user data for displaying farmer information
        users_info = {}
        from models import users
        for email, user in users.items():
            users_info[email] = {
                'name': user.name,
                'user_type': user.user_type
            }
    else:
        # For farmers, don't show listings on this page
        all_listings = []
        users_info = {}
    
    return render_template('waste_listing.html', form=form, listings=all_listings, user_type=current_user.user_type, users=users_info)

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    form = ContactForm()
    
    if form.validate_on_submit():
        # Create new contact message
        new_message = ContactMessage(
            name=form.name.data,
            email=form.email.data,
            subject=form.subject.data,
            message=form.message.data
        )
        
        flash('Your message has been sent! We will get back to you shortly.', 'success')
        return redirect(url_for('index'))
    
    return render_template('contact.html', form=form)

@app.context_processor
def utility_processor():
    def is_logged_in():
        return current_user.is_authenticated if current_user else False
    
    def get_current_user():
        return current_user if current_user.is_authenticated else None
    
    return dict(is_logged_in=is_logged_in, current_user=get_current_user)
