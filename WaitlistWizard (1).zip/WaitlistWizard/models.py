from datetime import datetime
from flask_login import UserMixin

# In-memory storage for users, waste listings, and contact messages
users = {}
waste_listings = []
contact_messages = []

class User(UserMixin):
    def __init__(self, email, name, phone, password, user_type, **kwargs):
        self.id = len(users) + 1  # Simple ID generation
        self.email = email
        self.name = name
        self.phone = phone
        self.password = password
        self.user_type = user_type  # 'farmer' or 'industrialist'
        self.created_at = datetime.utcnow()
        
        # Farmer specific fields
        self.farm_location = kwargs.get('farm_location')
        self.farm_size = kwargs.get('farm_size')
        
        # Industrialist specific fields
        self.company_name = kwargs.get('company_name')
        self.company_location = kwargs.get('company_location')
        
        # Store user in memory dictionary
        users[email] = self
    
    def get_id(self):
        return str(self.id)
        
    @classmethod
    def get_by_email(cls, email):
        return users.get(email)
        
    @classmethod
    def get_by_id(cls, id):
        for user in users.values():
            if user.id == int(id):
                return user
        return None


class WasteListing:
    def __init__(self, user_id, waste_type, quantity, description, location, available_from, available_until):
        self.id = len(waste_listings) + 1  # Simple ID generation
        self.user_id = user_id
        self.user_email = None
        # Find user's email for reference
        for email, user in users.items():
            if user.id == user_id:
                self.user_email = email
                break
        self.waste_type = waste_type
        self.quantity = quantity
        self.description = description
        self.location = location
        self.available_from = available_from
        self.available_until = available_until
        self.created_at = datetime.utcnow()
        
        # Add to in-memory list
        waste_listings.append(self)
    
    @classmethod
    def get_all(cls):
        return waste_listings
    
    @classmethod
    def get_by_user_id(cls, user_id):
        return [listing for listing in waste_listings if listing.user_id == user_id]


class ContactMessage:
    def __init__(self, name, email, subject, message):
        self.id = len(contact_messages) + 1  # Simple ID generation
        self.name = name
        self.email = email
        self.subject = subject
        self.message = message
        self.created_at = datetime.utcnow()
        
        # Add to in-memory list
        contact_messages.append(self)
