from flask_login import LoginManager

# Initialize login manager
login_manager = LoginManager()