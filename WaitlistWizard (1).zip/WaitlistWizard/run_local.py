"""
Local development script for VS Code users.
This script loads environment variables from .env file
before starting the application.
"""

import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Import app after loading environment variables
from app import app

if __name__ == "__main__":
    # Run the application
    app.run(host="0.0.0.0", port=5000, debug=True)