# AgriRenew - Agricultural Waste Recycling Platform

AgriRenew is a web platform that connects farmers and industrialists to transform agricultural waste into fertilizers, promoting sustainable agriculture practices.

## Project Overview

This platform allows:
- Farmers to list their agricultural waste (fruits and vegetables)
- Industrialists to discover and acquire agricultural waste materials
- Both parties to communicate and arrange waste collection/delivery
- Creation of a sustainable cycle of reuse in agriculture

## Technologies Used

- **Backend:** Python with Flask framework
- **Frontend:** HTML, CSS, JavaScript, Bootstrap
- **Storage:** In-memory data structures (no database required)
- **Authentication:** Flask-Login

## Setting Up the Project in VS Code

### Prerequisites

1. Python 3.8+ installed
2. Visual Studio Code with the Python extension (ms-python.python)
3. Git (optional, for cloning the repository)

### VS Code Configuration

For an optimal development experience in VS Code, consider adding the following configurations:

1. Create a `.vscode` folder with a `launch.json` file:

```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "AgriRenew: Run Local",
            "type": "python",
            "request": "launch",
            "program": "${workspaceFolder}/run_local.py",
            "console": "integratedTerminal",
            "justMyCode": true,
            "env": {
                "PYTHONPATH": "${workspaceFolder}"
            }
        }
    ]
}
```

2. Create a `.vscode/settings.json` file:

```json
{
    "python.linting.enabled": true,
    "python.linting.pylintEnabled": true,
    "python.formatting.provider": "autopep8",
    "editor.formatOnSave": true,
    "python.testing.pytestEnabled": true,
    "python.testing.unittestEnabled": false,
    "python.testing.nosetestsEnabled": false,
    "python.testing.pytestArgs": [
        "tests"
    ]
}
```

These configurations enable debugging, linting, and testing capabilities in VS Code.

### Step 1: Clone or Download the Repository

```bash
git clone https://your-repository-url-here.git
cd AgriRenew
```

Or download and extract the project files to a folder of your choice.

### Step 2: Set Up a Virtual Environment

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS/Linux
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Install Dependencies

```bash
pip install -r requirements.txt
```

If requirements.txt is not available, install the following packages:

```bash
pip install flask flask-login flask-wtf werkzeug email-validator python-dotenv gunicorn
```

### Step 4: Configure Environment Variables

Set up the .env file with your secret key:

```
SESSION_SECRET=your_secret_key_here
```

### Step 5: Run the Application

For local development with VS Code, use the run_local.py script which automatically loads environment variables from the .env file:

```bash
python run_local.py
```

Alternatively, you can use the standard main.py file:

```bash
python main.py
```

The application will start and be accessible at: http://localhost:5000

## Project Structure

- `app.py` - Core application with routes and configuration
- `main.py` - Application entry point
- `run_local.py` - Local development script for VS Code (loads .env variables)
- `models.py` - In-memory data models for users and waste listings
- `forms.py` - Form definitions for user input
- `database.py` - Minimal configuration for Flask-Login
- `.env` - Environment variables for local deployment
- `requirements-vscode.txt` - Package requirements for VS Code environment
- `templates/` - HTML templates for the website
  - `base.html` - Base template with shared layout
  - `index.html` - Homepage template
  - `about.html` - About page template
  - `process.html` - Process explanation page
  - `register.html` - User registration page
  - `login.html` - User login page
  - `profile.html` - User profile page
  - `waste_listing.html` - Waste listing creation/browsing page
  - `contact.html` - Contact form page
- `static/` - Static files (CSS, JavaScript, images)
  - `css/custom.css` - Custom CSS styles
  - `js/main.js` - JavaScript functionality

## Features

1. **User Authentication**
   - Registration for farmers and industrialists
   - User login and profile management

2. **Waste Listing Management**
   - Create waste listings with details (type, quantity, location, etc.)
   - Browse available waste listings

3. **Information Pages**
   - About page with information on the platform
   - Process page explaining the waste-to-fertilizer process
   - Contact page for support inquiries

## In-Memory Data Models

### User Model
- Stores user information for both farmers and industrialists
- Includes fields like name, email, phone, password, user type, etc.
- Data persists only for the current application session

### WasteListing Model
- Contains details about agricultural waste listings
- Includes waste type, quantity, description, location, availability dates, etc.
- Data persists only for the current application session

### ContactMessage Model
- Stores contact form submissions
- Includes name, email, subject, message, and creation timestamp
- Data persists only for the current application session

## Troubleshooting

### Application Issues

1. **Missing Dependencies Error**:
   - Run `pip install -r requirements.txt` to install all required packages
   - For specific packages: `pip install package-name`

2. **Module Import Error**:
   - Ensure you're running the application from the project root directory
   - Check that all required packages are installed

### Package Installation Issues

1. **Missing Package Error**:
   - If you encounter import errors, install the specific package:
     ```bash
     pip install package-name
     ```
   - Update the requirements-vscode.txt file if needed

2. **Version Compatibility Issues**:
   - If you encounter version conflicts, try installing exact versions:
     ```bash
     pip install flask==2.2.3 flask-login==0.6.2
     ```

### Application Startup Issues

1. **Address Already in Use Error**:
   - Another process might be using port 5000
   - Find and stop the process:
     ```bash
     # Windows
     netstat -ano | findstr :5000
     taskkill /PID <PID> /F
     
     # macOS/Linux
     lsof -i :5000
     kill -9 <PID>
     ```
   - Alternatively, change the port in run_local.py

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

[Include license information here]